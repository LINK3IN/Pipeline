﻿using AutoMapper;
using Fiap.Api.Alertas.Controllers;
using Fiap.Api.Alertas.Data;
using Fiap.Api.Alertas.Models;
using Fiap.Api.Alertas.Services;
using Fiap.Api.Alertas.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fiap.Api.Alertas.Teste
{
    public class AlertaControllerTest
    {
        private readonly Mock<IAlertaService> _alertaServiceMock;
        private readonly Mock<IMapper> _mapperMock;
        private readonly AlertaController _alertaController;

        public AlertaControllerTest()
        {
            _alertaServiceMock = new Mock<IAlertaService>();
            _mapperMock = new Mock<IMapper>();
            _alertaController = new AlertaController(_alertaServiceMock.Object, _mapperMock.Object);
        }

        [Fact]
        public void GetAll_ReturnsOkResult_WithAlertas()
        {
            // Arrange
            var alertas = new List<AlertaModel> { new AlertaModel { Id = 1, Titulo = "Teste" } };
            _alertaServiceMock.Setup(service => service.ListarAlertas(It.IsAny<int>(), It.IsAny<int>())).Returns(alertas);
            _mapperMock.Setup(mapper => mapper.Map<IEnumerable<AlertaViewModel>>(alertas)).Returns(new List<AlertaViewModel> { new AlertaViewModel { Id = 1, Titulo = "Teste" } });

            // Act
            var result = _alertaController.Get();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var viewModel = Assert.IsType<AlertaPaginacaoViewModel>(okResult.Value);
            Assert.Single(viewModel.Alertas);
        }

        [Fact]
        public void GetById_ReturnsOkResult_WithAlerta()
        {
            // Arrange
            var alerta = new AlertaModel { Id = 1, Titulo = "Teste" };
            _alertaServiceMock.Setup(service => service.ObterAlertaPorId(1)).Returns(alerta);
            _mapperMock.Setup(mapper => mapper.Map<AlertaViewModel>(alerta)).Returns(new AlertaViewModel { Id = 1, Titulo = "Teste" });

            // Act
            var result = _alertaController.GetById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var viewModel = Assert.IsType<AlertaViewModel>(okResult.Value);
            Assert.Equal(1, viewModel.Id);
        }

        [Fact]
        public void Post_ReturnsCreatedAtActionResult_WithAlerta()
        {
            // Arrange
            var viewModel = new AlertaViewModel { Id = 1, Titulo = "Teste" };
            var model = new AlertaModel { Id = 1, Titulo = "Teste" };
            _mapperMock.Setup(mapper => mapper.Map<AlertaModel>(viewModel)).Returns(model);
            _alertaServiceMock.Setup(service => service.CriarAlerta(model));

            // Act
            var result = _alertaController.Post(viewModel);

            // Assert
            var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
            var alertaModel = Assert.IsType<AlertaModel>(createdAtActionResult.Value);
            Assert.Equal(1, alertaModel.Id);
        }

        [Fact]
        public void Put_ReturnsNoContentResult_WhenAlertaUpdated()
        {
            // Arrange
            var viewModel = new AlertaViewModel { Id = 1, Titulo = "Teste" };
            var model = new AlertaModel { Id = 1, Titulo = "Teste" };
            _mapperMock.Setup(mapper => mapper.Map<AlertaModel>(viewModel)).Returns(model);
            _alertaServiceMock.Setup(service => service.AtualizarAlerta(model));

            // Act
            var result = _alertaController.Put(1, viewModel);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public void Delete_ReturnsNoContentResult_WhenAlertaDeleted()
        {
            // Arrange
            _alertaServiceMock.Setup(service => service.DeletarAlerta(1));

            // Act
            var result = _alertaController.Delete(1);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }
    }
}
